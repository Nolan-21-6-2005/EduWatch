import sqlite3
from datetime import datetime
from pathlib import Path

import cv2

from utils.helper import getdatabase_path

BASE_DIR = Path(__file__).resolve().parents[2]
EVIDENCE_DIR = BASE_DIR / "data_model" / "evidence"
EVIDENCE_DIR.mkdir(parents=True, exist_ok=True)

def _save_violation(
    label: str, 
    confidence: float, 
    frame, 
    camera_id: int | None, 
    session: str
):
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    image_path = EVIDENCE_DIR / f"detection_{timestamp}.jpg"
    if not cv2.imwrite(str(image_path), frame):
        image_path = None

    # Confidence của YOLO nằm trong [0, 1]. Từ 95% trở lên tự xác nhận.
    is_confirmed = 1 if float(confidence) >= 0.95 else 0
    review_status = "confirmed" if is_confirmed else "pending"
    with sqlite3.connect(getdatabase_path()) as conn:
        cursor = conn.execute(
            """
            INSERT INTO Violation_Logs
            (camera_id, loai_vi_pham, thoi_gian, session, image_path, confidence, is_confirmed, review_status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                camera_id,
                label,
                datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                session,
                str(image_path.relative_to(BASE_DIR)) if image_path else None,
                confidence,
                is_confirmed,
                review_status,
            ),
        )
        conn.commit()
        return cursor.lastrowid

